﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class changeQuestion : MonoBehaviour
{
    public GameObject changingText;
    // Start is called before the first frame update
    void Start()
    {
        //Put your questions in an array hena w khalih ykhtar random question menhom y display it w ru7y ba3daha lel game manager
        changingText.GetComponent<Text>().text = "Enter Your answer";
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    
}
