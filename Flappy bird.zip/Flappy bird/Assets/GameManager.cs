﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class GameManager : MonoBehaviour
{
    public GameObject GOCanvas;
    public GameObject inputText;
    private string answer;
    public GameObject questionObject;
    private string question;
    // Start is called before the first frame update
    void Start()
    {
        question = questionObject.GetComponent<Text>().text;
        GOCanvas.SetActive(false);
        Time.timeScale =1;
    }
    private void StartGame(){
        GOCanvas.SetActive(false);
        Time.timeScale =1;
    }
    public void GameOver(){
        GOCanvas.SetActive(true);
        Time.timeScale =0;
    }

    public void CheckInput(){
        //hena 7oty elquestions array w elanswers array ba3den search for the 
        //question ana 3amelhalek variable fou2 in the array w get its index w shufi law elanswer bta3to zay elanswer elfelindex da felarray bta3 elanswers
        /*
            if his answer is the same as yours
                StartGame();
            else
                Replay();
        */
        //da hayob2a shakl elif statement bas e3meli ablaha for statement 3ashan tgiby elindex bta3 elso2al w khali egabet kol so2al f nafs elindex
        //ya3ni so2al elfy index 0 egabto f index 0 wahakaza, lefy felquestions array 
        //giby elindex bta3 elso2al w 7ottih felanswers array w check if its the same as his answer
        answer = inputText.GetComponent<Text>().text;
        if(answer == "hello"){
            StartGame();
        }
        else{
            Replay();
        }
        
    }
    public void Replay(){
        SceneManager.LoadScene(0);
    }
    
}
